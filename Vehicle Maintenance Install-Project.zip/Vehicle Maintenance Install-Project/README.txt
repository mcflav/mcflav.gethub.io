*** Vehicle Maintenanace Single User Desktop Application ***
** This Application allows a user to create a single user account and add one vehicle to the application. This application montitors the vehicle's services throughtout 
** the years. It also keep track of when the user checks the oil in the vehicle to ensure the oil doesn't run low. 
***********************************************************************************************************************************************************************

Before running this application you must have SQLExpress and Microsoft SQL Server Management Studio installed on the local machine. The SQLExpress install should create the below path after the install:

C:\Program Files\Microsoft SQL Server\MSSQL11.SQLEXPRESS\MSSQL\DATA


Follow below steps to set up database for the application:

 - Open DB Scripts folder within the Vehicle MaintenanceSQLServerSingleUser folder  and save the all files to c:\qttemp (create_vehicle_maintenance_database.sql, create_VM_database.bat, and carOwnerId_seq.sql)

 - Right click the create_VM_database.bat and select "Run as administrator". This will create the VehicleMaintPro database.

 - Next, open SQL Server Management Studio and the carOwnerId_seq.sql file (using notepad for the file).

 - Find the VehicleMaintPro database in SQL Server Management Studo right click on it and select New Query.

 - Copy the contents from the carOwnerId_seq.sql file into the query window and click the execute button to execute the query.

 - Close SQL Server Management Studio. Go into Windows Services (Start | Search - type services.msc and hit enter). Right click on the SQLExpress service and select    Restart. 

 - You are ready to go!!